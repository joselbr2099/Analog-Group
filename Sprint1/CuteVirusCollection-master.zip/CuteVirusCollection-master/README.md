# CuteVirusCollection
#### A Collection of Cute But Deadly Viruses

They will instantly snatch control from you. Then will sicken your high-end PC by overflowing the RAM & overwhelming the processor. And you will see your computer groaning till it crashes. Believe me, viruses were never so lovely before.

Computer is a very complex machine. You just have to break one support to crash the whole structure. It can be done in many ways- overloading the processor, overflowing the RAM, flooding the hard-disk, occupying input/output system or any other resource, and erasing essential software (like- operating system). Follow the [Cute Rank](#cute-rank) for getting a categorical view of the project. Programs are categorized according to their danger level.

## Cute Rank

### Level-1: Banana
Code | Intro
--- | --- 
[out_of_control.java](https://github.com/MinhasKamal/CuteVirusCollection/blob/master/out_of_control.java) | Randomly moves the mouse pointer, & clicks different places on the screen.
[chaos_devil.c](https://github.com/MinhasKamal/CuteVirusCollection/blob/master/chaos_devil.c) | Randomly moves the window round. Only Ctrl+Alt+Del will work here.
[dark_screen.c](https://github.com/MinhasKamal/CuteVirusCollection/blob/master/dark_screen.c) | Simply shuts the system down.

### Level-2: Orange
Code | Intro
--- | --- 
[memory_crash.html](https://github.com/MinhasKamal/CuteVirusCollection/blob/master/memory_crash.html) | Creates a super big string and overwhelms the RAM.
[browser_breaker.html](https://github.com/MinhasKamal/CuteVirusCollection/blob/master/browser_breaker.html) | The site contains JS code which generates an infinite string of characters that overwhelms the memory. 
[cmd_blast.c](https://github.com/MinhasKamal/CuteVirusCollection/blob/master/cmd_blast.c) | Opens an infinite number of command prompt window till the system crushes.
[unclosable.html](https://github.com/MinhasKamal/CuteVirusCollection/blob/master/unclosable.html) | Opens lots of windows in the browser and crushes the PC.
[serious_punch.c](https://github.com/MinhasKamal/CuteVirusCollection/blob/master/serious_punch.c) | A fork-bomb that creates lots of child process till the computer gives up.
[fork_bomb.sh](https://github.com/MinhasKamal/CuteVirusCollection/blob/master/fork_bomb.sh) | Creates an infinite number of processes.
[ram_slayer.c](https://github.com/MinhasKamal/CuteVirusCollection/blob/master/ram_slayer.c) | Consumes full space of the RAM.

### Level-3: Strawberry
Code | Intro
--- | --- 
[cpu_eater.bat](https://github.com/MinhasKamal/CuteVirusCollection/blob/master/cpu_eater.bat) | This batch program recursively executes itself forever and takes up full CPU usage.
[folder_flooder.bat](https://github.com/MinhasKamal/CuteVirusCollection/blob/master/folder_flooder.bat) | Creates a lot of folders on the disk.


**Note**: I have personally tested all of the programs on my laptop; no permanent damage was caused by any of them. But I cannot guarantee your safety. So **run them on your own risk**. 

You can stop them by pressing *Ctrl+Alt+Del* or kill the process with task manager. For testing, you may also use online compilers, like- [TutorialsPoint-CodingGround](https://www.tutorialspoint.com/codingground.htm) or [repl.it](https://repl.it/languages).

## Resources
- [Smallest piece of code that can crash the computer](https://www.quora.com/What-is-your-smallest-piece-of-code-that-can-crash-the-computer).
- [Crash my computer](https://www.quora.com/How-do-I-crash-my-computer).

## License
[MIT License](https://opensource.org/licenses/MIT).
