VirusCollection
===============

A virus collection level1 ~ level100! try and death now!
