# Albanian Virus
<h2>Source code of Albanian Virus written in C#</h2>

#### Just in case you want to send it to your friends, you can use the binary from here:
### [https://github.com/Wolfterro/Albanian-Virus/releases/tag/v1.0](https://github.com/Wolfterro/Albanian-Virus/releases/tag/v1.0)

<br />

#### Or, in case you want to compile it yourself (using Microsoft .NET CSharp Compiler):

    csc /r:System.Windows.Forms.dll AlbanianVirus.cs
    AlbanianVirus.exe

#### Best regards,
#### Albanian virus.
