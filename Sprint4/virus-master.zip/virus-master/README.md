# virus
# i am not responsible for what you are gonna do with this source code
a virus that creates random folders at your desktop, pics folder, docs folder and so on. it also opens a text file that says "GET SHREKT MOIT". it also deletes google chrome and firefox. made in c sharp.
